"""Empirical anchor for the 50-card verdict: can one 3090 hold one (or two)
full-size K3 MoE layers in packed MXFP4 layout? Real config numbers:
896 experts x 3 mats x 3584x3072, 4-bit packed + E8M0 scale per 32."""
import torch
E, REH, MI = 896, 3584, 3072
params = E * 3 * REH * MI
packed = params // 2          # uint8 nibbles
scales = params // 32         # E8M0 uint8
gb = (packed + scales) / 1e9
print(f"one layer: {params/1e9:.1f}B params -> {gb:.2f} GB packed")
torch.cuda.init(); dev = "cuda:0"
free0 = torch.cuda.mem_get_info(0)[0] / 1e9
print(f"free on GPU0: {free0:.1f} GB")
bufs = []
for layer in (1, 2):
    try:
        bufs.append((torch.empty(packed, dtype=torch.uint8, device=dev),
                     torch.empty(scales, dtype=torch.uint8, device=dev)))
        print(f"layer {layer}: ALLOCATED (total {layer*gb:.1f} GB)")
    except torch.OutOfMemoryError:
        print(f"layer {layer}: OOM — {layer} layers do NOT fit a 24GB card")
        break
free = torch.cuda.mem_get_info(0)[0] / 1e9
print(f"free after: {free:.1f} GB")
