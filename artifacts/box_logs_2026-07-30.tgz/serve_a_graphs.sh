#!/bin/bash
# Phase A: bf16 slice, PP=2, sm_86. Usage: bash serve_a.sh [extra vllm args]
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export VLLM_USE_V2_MODEL_RUNNER=1
export FLASHINFER_DISABLE_VERSION_CHECK=1
exec python3 -m vllm.entrypoints.openai.api_server \
  --model /workspace/k3/k3-slice --served-model-name k3-slice \
  --trust-remote-code --load-format dummy \
  --pipeline-parallel-size 1 --tensor-parallel-size 1 \
  --kv-cache-dtype auto --max-model-len 4096 \
  --gpu-memory-utilization 0.9 --port 18002 "$@"
