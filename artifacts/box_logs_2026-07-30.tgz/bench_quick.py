import json, time, urllib.request, statistics as st
URL = "http://127.0.0.1:18000/v1/completions"
def run(prompt_toks, max_toks, n=4):
    prompt = " hello" * prompt_toks
    lat, first = [], []
    for _ in range(n):
        t0 = time.time()
        req = urllib.request.Request(URL, json.dumps({
            "model": "k3-slice", "prompt": prompt,
            "max_tokens": max_toks, "temperature": 0.0}).encode(),
            {"Content-Type": "application/json"})
        r = json.load(urllib.request.urlopen(req, timeout=300))
        dt = time.time() - t0
        lat.append(dt)
    med = st.median(lat)
    print(f"prefill~{prompt_toks}t gen={max_toks}t: median {med:.2f}s "
          f"({max_toks/med:.1f} tok/s incl prefill)")
if __name__ == "__main__":
    run(64, 64); run(1024, 64); run(64, 256)
